import 'package:flutter/material.dart';


class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
     crossAxisAlignment: CrossAxisAlignment.start,
      children:<Widget> [
        Padding(
      padding: EdgeInsets.symmetric(horizontal:20.0,),
      child:Text("Women", 
      style:Theme.of(context).textTheme.headline5.copyWith(fontWeight:FontWeight.bold),
      
      ),
      ),
     Categories(),
      ],  
    );
  }
}
class Categories extends StatefulWidget {
  @override
  _CategoriesState createState() => _CategoriesState();
}

class _CategoriesState extends State<Categories> {
  List<String>categories= ["Handbags","Dress","Jewellery","Footwear"];
  int selectedindex=0;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height:25,
      child: ListView.builder(
         scrollDirection: Axis.horizontal,
         itemCount: categories.length,
         itemBuilder: (context, index) => buildText(index)
                  ),   
                      );
                    }

  Widget buildText(int index) {
  return GestureDetector(
    onTap:()
    {
    setState(() { selectedindex =index; });
  },
  child:Padding(
    padding: EdgeInsets.symmetric(horizontal:25.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(categories[index],
         style:
         TextStyle(fontWeight: FontWeight.bold,
         color:selectedindex==index ?Color(0xFF535353):Colors.grey),
  ),
  Container(
    margin: EdgeInsets.only(top:10/4),
    height:2,
    width:30,
    color: selectedindex==index ?Colors.black :Colors.transparent,

  )
      ],
    ),
  )
  );
  }
  }


  