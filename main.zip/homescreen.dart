import 'package:flutter/material.dart';
import 'package:shoppingcart/body.dart';

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:buildAppBar(),
      body: Body(),
    );
  }

  AppBar buildAppBar() { 
    return AppBar(
    backgroundColor: Colors.white,
    elevation:5,
    actions:[
      IconButton(icon :Icon(Icons.local_grocery_store_outlined),onPressed: ()=>{},color:Colors.black),
      IconButton(icon :Icon(Icons.search_off_rounded),onPressed: ()=>{}, color:Colors.black,),
    ],
    leading:Icon(Icons.arrow_back_outlined,color:Colors.black),
    title: Text('ShopX',style:TextStyle(color: Colors.black),),
    centerTitle:true,
    );
  }
}